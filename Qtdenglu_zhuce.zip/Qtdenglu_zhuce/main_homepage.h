#ifndef MAIN_HOMEPAGE_H
#define MAIN_HOMEPAGE_H

#include <QDialog>
#include <QSqlTableModel>

namespace Ui {
class Main_homepage;
}

class Main_homepage : public QDialog
{
    Q_OBJECT

public:
    explicit Main_homepage(QWidget *parent = nullptr);
    ~Main_homepage();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Main_homepage *ui;
    QSqlTableModel *model;
};

#endif // MAIN_HOMEPAGE_H
