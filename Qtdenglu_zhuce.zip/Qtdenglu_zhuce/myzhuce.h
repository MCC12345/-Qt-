#ifndef MYZHUCE_H
#define MYZHUCE_H

#include <QWidget>

namespace Ui {
class myzhuce;
}

class myzhuce : public QWidget
{
    Q_OBJECT

public:
    explicit myzhuce(QWidget *parent = nullptr);
    ~myzhuce();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_lineEdit_textChanged(const QString &arg1);

private:
    Ui::myzhuce *ui;
};

#endif // MYZHUCE_H
