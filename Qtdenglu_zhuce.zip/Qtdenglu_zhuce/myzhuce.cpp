#include "myzhuce.h"
#include "ui_myzhuce.h"
#include "mainwidget.h"
#include <QSqlQuery>
#include "QDebug"
#include <QMessageBox>

myzhuce::myzhuce(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::myzhuce)
{
    ui->setupUi(this);
    //连接数据库
    QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
            db1.setDatabaseName("../shujuku/test.db");
            bool res1 = db1.open();
            qDebug() << res1;
}

myzhuce::~myzhuce()
{
    delete ui;
}

void myzhuce::on_pushButton_2_clicked()
{
    mainWidget *d = new mainWidget;
    d->show();
    this->close();
}
    //按下注册界面确认按钮触发一下操作
void myzhuce::on_pushButton_clicked()
{


    //获取三个LineEdit框中内容
    QString username = ui->lineEdit->text();
    QString password = ui->lineEdit_2->text();
    QString confirmPassword = ui->lineEdit_3->text();

    if(password != confirmPassword)
    {
        QMessageBox::warning(this,"提示","密码输入不一致");
    }
    //获取系统中id值最大是多少
    QString userid;
    QSqlQuery query;
    query.exec("SELECT MAX(IDname) FROM houseDB;");
    if(query.next())
    {
            userid = query.value(0).toString();
    }
    qDebug() << userid;


    //向houseDB表中增加新用户信息
    //userid.toInt()+1
    QSqlQuery query1;
    query1.prepare("insert into houseDB(IDname,username,password) VALUES(:id,:name,:pwd)");
    query1.bindValue(":id",userid.toInt()+1);
    query1.bindValue(":name",username);
    query1.bindValue(":pwd",password);
    query1.exec();
}
//只要用户输入框的文字发生改变，就会触发该函数
void myzhuce::on_lineEdit_textChanged(const QString &arg1)
{
    qDebug() << arg1;
    //用户名自检
    QSqlQuery query;
    query.prepare("select * from houseDB where username = :name");
    query.bindValue(":name",arg1);
    query.exec();
    if(query.next())
    {
        ui->pushButton->setEnabled(false);
    }
    else
    {
        ui->pushButton->setEnabled(true);
    }
}
