#include "mainwidget.h"
#include <QApplication>
#include "main_homepage.h"
#include "main_homepage.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    mainWidget w;
    w.show();
    return a.exec();
}
