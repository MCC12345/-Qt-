#include "main_homepage.h"
#include "ui_main_homepage.h"
#include <QSqlTableModel>
#include "QDebug"
#include <QMessageBox>

Main_homepage::Main_homepage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Main_homepage)
{
    ui->setupUi(this);
    model = new QSqlTableModel(this);
    //将表放入到模型中
    model->setTable("houseDB");
    model->select();//选择数据
    //手动提交模式
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    //将数据模型对象放入控件（view）中显示
    ui->tableView->setModel(model);
}

Main_homepage::~Main_homepage()
{
    delete ui;
}

//新增
void Main_homepage::on_pushButton_clicked()
{
    //获取当前系统中有多少行
    int rowNum = model->rowCount();
    qDebug() << rowNum;
    //新增一行
    model->insertRow(rowNum);
}
//保存按钮
void Main_homepage::on_pushButton_2_clicked()
{
    //1.开启事务操作
    model->database().transaction();
    //2.判断事务的操作状态
    if(model->submitAll())
    {    // 提交
        model->database().commit();
    }
    else //回滚
    {
        model->database().rollback();
    }
}

//删除
void Main_homepage::on_pushButton_3_clicked()
{
    //1.获取选中的行
    int currentRow = ui->tableView->currentIndex().row();
    qDebug() << currentRow;
    //2.删除该行
    model->removeRow(currentRow);
    //3.提示窗口，提示是否真的要删除数据
   int flag = QMessageBox::warning(this,"删除当前行","确定是否删除当前行",QMessageBox::Yes,QMessageBox::No);

   if(flag == QMessageBox::No)
   {
       //不想删除
       model->revertAll();
   }
   else
   {
        model->submitAll();
   }
}
