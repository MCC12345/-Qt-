#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "main_homepage.h"
#include "myzhuce.h"
#include <QSqlQuery>
#include <QMessageBox>
#include "QDebug"

mainWidget::mainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::mainWidget)
{
    ui->setupUi(this);
}

mainWidget::~mainWidget()
{
    delete ui;
}

void mainWidget::on_pushButton_clicked()
{


    QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
            db1.setDatabaseName("../shujuku/test.db");
            bool res1 = db1.open();
            qDebug() << res1;
          //连接好数据库后，查询语句，将查询结果放到Qt程序中显示
        QSqlQuery query;
       query.exec("select * from houseDB");

        while(query.next())
        {
            QString userid = query.value("IDname").toString();
            QString username = query.value("username").toString();
            QString password = query.value("password").toString();

           // qDebug() << userid << "" << username << "" << password;
         //用户输入的名字和密码
            QString username_y = ui->lineEdit->text();
            QString password_y = ui->lineEdit_2->text();

          //qDebug() << username_y << "" << password_y;


    //登录按钮,跳转到主界面
    //将输入名字和密码进行比对 如果相同进行才进行跳转
            if(username == username_y and password == password_y)
            {
                Main_homepage *z = new Main_homepage;
                z->show();
                this->close();

            }

         }
        //账号与密码不匹配 显示错误窗口


}

void mainWidget::on_pushButton_2_clicked()
{
    //注册按钮，跳转到注册界面
    myzhuce *c = new myzhuce;
    c->show();
    this->close();
}
